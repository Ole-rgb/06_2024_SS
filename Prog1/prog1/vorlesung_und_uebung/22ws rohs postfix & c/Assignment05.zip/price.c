/*
 * Compile:         make X
 * Run:             ./X
 * Compile and Run: make X && ./X
 */
#include "base.h" // prog1lib

// todo: define constants

// todo: write function price

// todo: write function price_test
// test returned values of price using test_equal_i

int main(void) {
    // todo: call price_test function

    return 0;
}
