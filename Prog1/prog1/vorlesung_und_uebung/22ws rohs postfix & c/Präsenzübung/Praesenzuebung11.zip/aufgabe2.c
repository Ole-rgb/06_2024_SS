/*
Compile: make aufgabe2
Run: ./aufgabe2
make aufgabe2 && ./aufgabe2
*/

#include "base.h"

typedef struct Node Node;
struct Node {
    String name;
    int value;
    Node* next;
};

Node* new_node(String name, int value, Node* next) {
    Node* node = xcalloc(1, sizeof(Node));
    node->name = name;
    node->value = value;
    node->next = next;
    return node;
}

void fprint_node(FILE* file, Node* node) {
    fprintf(file, "%s: %d", node->name, node->value);
}

void fprint_nodes(FILE* file, Node* list) {
    fprintf(file, "[");
    for (Node* node = list; node; node = node->next) {
        fprint_node(file, node);
        if (node->next) fprintf(file, ", ");
    }
    fprintf(file, "]\n");
}

// Creates a list of node-value-pairs of a string s of the form "apples:3,oranges:2,...,nuts:1".
Node* list_from_string(String s) {
    Node* list = NULL;
    if (s == NULL) return list;
    char* a = s;
    char* b;
    char* c;
    int n;
    while (*a) {
        b = strchr(a, ':');
        if (b == NULL) return list;
        c = strchr(b + 1, ',');
        if (c == NULL) c = b + strlen(b);
        n = b - a;
        char* name = xmalloc(n + 1);
        memcpy(name, a, n);
        name[n] = '\0';
        n = c - (b + 1);
        char* value = xmalloc(n + 1);
        memcpy(value, b + 1, n);
        value[n] = '\0';
        list = new_node(name, atoi(value), list);
        if (*c) a = c + 1; else a = c;
    }
    return list;
}

// Finds the first node in the list whose name is name. Returns NULL if no such node is present.
Node* find_node(Node* list, String name) {
    return NULL;
}

// Computes the total price of each item by item. Count contains a list of items 
// together with a count value. Each item can appear multiple times. Prices cotains
// the price (in cents) of each item. In this list, each item appears exactly once.
Node* total_by_item(String counts, String prices) {
    return NULL;
}

void test(void) {
    String counts = "apples:1,oranges:1,apples:1"; // 2 apples and 1 orange
    String prices = "apples:60,oranges:100"; // an apple costs 60 cent, an orange 100 cent
    Node* list = total_by_item(counts, prices);
    FILE* f = fopen("tmp.txt", "w");
    fprint_nodes(f, list);
    fclose(f);
    test_equal_s(s_read_file("tmp.txt"), "[oranges: 100, apples: 120]\n");

    counts = "apples:3,oranges:5,apples:1,nuts:2,apples:2";
    prices = "apples:99,oranges:149,nuts:199";
    list = total_by_item(counts, prices);
    f = fopen("tmp.txt", "w");
    fprint_nodes(f, list);
    fclose(f);
    test_equal_s(s_read_file("tmp.txt"), "[oranges: 745, nuts: 398, apples: 594]\n");
}

int main(void) {
    test();
    return 0;
}
