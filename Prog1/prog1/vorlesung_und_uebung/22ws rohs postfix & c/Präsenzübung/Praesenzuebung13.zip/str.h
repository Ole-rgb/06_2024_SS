/** @file
A Str is a wrapper of a C string.
@author Michael Rohs
@date 07.01.2021
@copyright Apache License, Version 2.0
*/

#ifndef STR_H_INCLUDED
#define STR_H_INCLUDED

#include "base.h"
#include "object.h"

/**
Creates a Str from a zero-terminated C-String. Creates its own copy of s.
@param[in] s the zero-terminated C string used to initialize the Str
@return the Str
@pre "not null", s
@post "correct class", is_str(result)
*/
Object* new_str(String s);

/**
Checks if x is a Str.
@param[in] x the object to check, may be NULL
@return true if x is a Str, false if x is NULL or not a Str
*/
bool is_str(Object* x);

/**
Compares x and y.
@param[in] x the first Str to compare
@param[in] y the second Str to compare
@return 0 if x and y are equal, <0 if x is lexicographically smaller than y, >0 otherwise
@pre "correct class", is_str(x)
@pre "correct class", is_str(y)
*/
int compare_strs(Object* x, Object* y);

#endif
