#include "class.h"
#include "book.h"

Object* copy_book(Object* x);
void delete_book(Object* x);
bool books_equal(Object* x, Object* y);
String book_to_string(Object* x);

/// Represents information about authors, a title, and a year of publication.
typedef struct Book {
    Class* class; ///< a pointer to book_class
    String authors; ///< the authors of the book
    String title; ///< the title of the book
    int year; ///< the year of publication of the book
} Book;

static Class book_class;

static Class* get_book_class(void) {
    if (book_class.copy == NULL) {
        book_class.name = "Book";
        book_class.copy = copy_book;
        book_class.delete = delete_book;
        book_class.equal = books_equal;
        book_class.to_string = book_to_string;
    }
    return &book_class;
}

bool is_book(Object* x) {
    if (x == NULL) return false;
    return x->class == &book_class;
}

Object* new_book(String authors, String title, int year) {
    require_not_null(authors);
    require_not_null(title);
    Book* b = xcalloc(1, sizeof(Book));
    b->class = get_book_class();
    b->authors = s_copy(authors);
    b->title = s_copy(title);
    b->year = year;
    ensure("correct class", is_book((Object*)b));
    return (Object*)b;
}

Object* copy_book(Object* x) {
    require("correct class", is_book(x));
    Book* b = (Book*)x;
    return new_book(b->authors, b->title, b->year);
}

String book_to_string(Object* x) {
    require("correct class", is_book(x));
    Book* b = (Book*)x;
    String year = s_of_int(b->year);
    int n = s_length(b->authors) + 2 + s_length(b->title) + 2 + s_length(year) + 1 + 1;
    String s = xmalloc(n);
    snprintf(s, n, "%s: %s, %s.", b->authors, b->title, year);
    free(year);
    return s;
}

void delete_book(Object* x) {
    require("correct class", is_book(x));
    Book* b = (Book*)x;
    free(b->title);
    free(b->authors);
    free(b);
}

bool books_equal(Object* x, Object* y) {
    require_not_null(x);
    Book* a = (Book*)x;
    Book* b = (Book*)y;
    if (a == b) return true;
    if (a == NULL || b == NULL) return false;
    if (a->class != b->class) return false;
    require("correct class", is_book(x));
    require("correct class", is_book(y));
    return s_equals(a->authors, b->authors) && s_equals(a->title, b->title) && (a->year == b->year);
}

String book_authors(Object* x) {
    require("correct class", is_book(x));
    Book* b = (Book*)x;
    return b->authors;
}
String book_title(Object* x) {
    require("correct class", is_book(x));
    Book* b = (Book*)x;
    return b->title;
}

int book_year(Object* x) {
    require("correct class", is_book(x));
    Book* b = (Book*)x;
    return b->year;
}

