/** @file
This module declares the functions that are common to each Object.
@author Michael Rohs
@date 07.01.2021
@copyright Apache License, Version 2.0
*/

#ifndef OBJECT_H_INCLUDED
#define OBJECT_H_INCLUDED

#include "base.h"

/// Represents an individual object.
typedef struct Object Object;

/**
Returns the class name of the object. The same pointer is returned for each 
instance of the same class.
@param[in] object the object whose class name is to be determined
@return the class name as an immutable string
@pre "not null", object
*/
String class_name(Object* object);

/**
Creates a copy of the object.
@param[in] object the object to copy
@return the copy
@pre "not null", object
*/
Object* copy(Object* object);

/**
Deletes the object.
@param[in] object the object to delete
@pre "not null", object
*/
void delete(Object* object);

/**
Checks if two objects are equal.
@param[in] obj1 the first object to compare
@param[in] obj2 the second object to compare
@return true if the objects are equal, false otherwise
@pre "not null", obj1
@pre "not null", obj2
*/
bool equal(Object* obj1, Object* obj2);

/**
Returns a string representation of the object.
@param[in] object
@return dynamically allocated string representation of the object
@pre "not null", object
*/
String to_string(Object* object);

#endif
