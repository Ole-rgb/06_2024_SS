/*
Compile: make aufgabe1
Run: ./aufgabe1
make aufgabe1 && ./aufgabe1
*/

#include "base.h"
#include "book.h"
#include "str.h"
#include "object_list.h"

// (a)
Object* to_title(Object* element, int i, void* x) {
    require("is book", is_book(element));
    return new_str(book_title(element));
}

// (b)
// ...

// (d)
// ...

// (e)
// ...

int main(void) {
    Node* books = NULL;
    books = new_node(new_book("Charles Petzold", "Code: The Hidden Language of Computer Hardware and Software", 2000), books);
    books = new_node(new_book("Robert Sedgewick and Kevin Wayne", "Algorithms", 2011), books);
    books = new_node(new_book("Bertrand Meyer", "Object-Oriented Software Construction", 1988), books);
    books = new_node(new_book("Niklaus Wirth", "Project Oberon – The Design of an Operating System and Compiler", 1992), books);
    books = new_node(new_book("Peter Sestoft", "Proogramming Language Concepts", 2012), books);
    books = new_node(new_book("David Benyon", "Designing Interactive Systems", 2010), books);
    books = new_node(new_book("Alice", "Cryptography", 2000), books);
    books = new_node(new_book("Bob", "C-Programming", 2001), books);
    books = new_node(new_book("Eve", "PostFix", 2020), books);

    // (a)
    Node* titles = map_list(books, to_title, NULL);
    println_list(titles);

    // (b)
    int year = 2000;
    printiln(year);
    Node* old_books = NULL; // = filter_list(books, before, &year);
    println_list(old_books);

    // (c)
    Node* titles_of_old_books = NULL; // = filter_map_list(books, before, to_title, &year);
    println_list(titles_of_old_books);

    // (d)
    Node* result = NULL;
    // reduce_list(books, titles_of_books_before_2000, &result);
    println_list(result);

    // (e)
    struct { Node* result; int year; } result_and_year = { NULL, 2000 };
    // reduce_list(books, titles_of_books_before, &result_and_year);
    println_list(result_and_year.result);

    return 0;
}
