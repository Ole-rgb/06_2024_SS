/** @file
A Book represents information about authors, a title, and a year of publication.
@author Michael Rohs
@date 07.01.2021
@copyright Apache License, Version 2.0
*/

#ifndef BOOK_H_INCLUDED
#define BOOK_H_INCLUDED

#include "base.h"
#include "object.h"

/**
Creates a Book. Creates its own copies of authors and title.
@param[in] authors zero-terminated C string
@param[in] title zero-terminated C string
@param[in] year the year of publication
@return the Book
@pre "not null", authors
@pre "not null", title
@post "correct class", is_book(result)
*/
Object* new_book(String authors, String title, int year);

/**
Checks if x is a Book.
@param[in] x the object to check, may be NULL
@return true if x is a Book, false if x is NULL or not a Book
*/
bool is_book(Object* x);

/**
Returns the authors of the book. Returns a pointer to the internal string.
@param[in] x the book
@return the authors of the book (pointer to the internal string)
@pre "correct class", is_book(x)
*/
String book_authors(Object* x);

/**
Returns the title of the book. Returns a pointer to the internal string.
@param[in] x the book
@return the title of the book (pointer to the internal string)
@pre "correct class", is_book(x)
*/
String book_title(Object* x);

/**
Returns the publication year of the book.
@param[in] x the book
@return the publication year of the book
@pre "correct class", is_book(x)
*/
int book_year(Object* x);

#endif
