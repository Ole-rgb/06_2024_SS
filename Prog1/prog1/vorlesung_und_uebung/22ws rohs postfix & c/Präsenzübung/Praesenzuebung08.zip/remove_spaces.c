/*
make remove_spaces && ./remove_spaces
*/
#include "base.h"

void remove_spaces(char* s) {
    // implement
}

int main(void) {
    char s[64];

    strcpy(s, "a   bb   c ");
    remove_spaces(s);
    test_equal_s(s, "abbc");

    strcpy(s, " aa  bbb cccc ");
    remove_spaces(s);
    test_equal_s(s, "aabbbcccc");

    strcpy(s, "   ");
    remove_spaces(s);
    test_equal_s(s, "");

    return 0;
}
