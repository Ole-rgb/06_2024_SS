/*
Compile: make shape
Run: ./shape
make shape && ./shape
*/

#include "base.h"

#undef M_PI
#define M_PI 3.14159265358979323846264338327950288419716939937510

typedef struct {
    enum { CIRCLE, RECTANGLE } tag;
    union { 
        struct { double x, y, radius; } circle;
        struct { double x, y, width, height; } rectangle;
    };
} Shape;

Shape make_circle(double x, double y, double r) {
    require("non-negative radius", r >= 0);
    Shape s;
    s.tag = CIRCLE;
    s.circle.x = x;
    s.circle.y = y;
    s.circle.radius = r;
    return s;
}

Shape make_rectangle(double x, double y, double w, double h) {
    require("non-negative width", w >= 0);
    require("non-negative height", h >= 0);
    Shape s;
    s.tag = RECTANGLE;
    s.rectangle.x = x;
    s.rectangle.y = y;
    s.rectangle.width = w;
    s.rectangle.height = h;
    return s;
}

void print_shape(Shape s) {
    switch (s.tag) {
    case CIRCLE:
        printf("circle: %g %g %g\n", 
            s.circle.x , s.circle.y , 
            s.circle.radius);
        break;
    case RECTANGLE:
        printf("rectangle: %g %g %g %g\n", 
            s.rectangle.x, s.rectangle.y, 
            s.rectangle.width, 
            s.rectangle.height);
        break;
    }
}

// Computes the area of the shape.
double area(Shape s) {
	// implementation...
    return 0;
}

// documentation
// precondition
Shape scale_area(Shape s, double factor) {
	// precondition...
	// implementation...
	// postcondition...
    return s;
}

int main(void) {
    Shape c = make_circle(100, 50, 20);
    print_shape(c);

    Shape r = make_rectangle(10, 20, 30, 40);
    print_shape(r);
    
    printf("%lu, %lu\n", sizeof(c), sizeof(Shape));

    printf("%.2f\n", area(c));
    printf("%.2f\n", area(r));
    Shape d = scale_area(c, 1.5);
    Shape s = scale_area(r, 1.5);
    printf("%.2f\n", area(d));
    printf("%.2f\n", area(s));
    return 0;
}
