/*
Compile: make account
Run: ./account
make account && ./account
*/

#include "base.h"

typedef struct {
    String owner;
    int balance;
} Account;

// Opens a new account with an initial balance.
// document preconditions...
Account open_account(String owner, int initial) {
	// preconditions...
    Account a;
    a.owner = owner;
    a.balance = initial;
    return a;
}

// Deposits amount into account.
// document preconditions...
Account deposit(Account a, int amount) {
	// preconditions...
	// implementation...
    return a;
}

// Withdraws amount from account.
// document preconditions...
Account withdraw(Account a, int amount) {
	// preconditions...
	// implementation...
	// postcondition...
    return a;
}

// Gets the current balance of the account.
int balance(Account a) {
    return a.balance;
}

// Gets the owner of the account.
String owner(Account a) {
    return a.owner;
}

int main(void) {
    Account a = open_account("Ida", 100);
    printiln(balance(a));
    a = deposit(a, 10);
    printiln(balance(a));
    a = withdraw(a, 20);
    printiln(balance(a));
    a = withdraw(a, 80);
    printiln(balance(a));
    return 0;
}
