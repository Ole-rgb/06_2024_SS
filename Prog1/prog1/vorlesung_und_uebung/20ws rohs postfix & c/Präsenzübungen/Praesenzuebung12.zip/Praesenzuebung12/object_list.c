#include "object_list.h"

/// Represents a single list node.
struct Node {
    Object* value; ///< points to an Object
    struct Node* next; ///< self-reference
};

Node* new_node(Object* value, Node* next) {
    require_not_null(value);
    Node* node = xcalloc(1, sizeof(Node));
    node->value = value;
    node->next = next;
    return node;
}

void print_list(Node* list) {
    if (list == NULL) {
        printf("[]");
    } else {
        Object* o = list->value;
        assert_not_null(o);
        String s =  to_string(o);
        printf("[%s", s);
        free(s);
        for (Node* n = list->next; n != NULL; n = n->next) {
            o = n->value;
            assert_not_null(o);
            s = to_string(o);
            printf(", %s", s);
            free(s);
        }
        printf("]");
    }
}

void println_list(Node* list) {
    print_list(list);
    printsln("");
}

void free_list(Node* list, bool free_element) {
    Node* node_next = NULL;
    for (Node* node = list; node != NULL; node = node_next) {
        node_next = node->next;
        Object* o = node->value;
        assert_not_null(o);
        if (free_element) delete(o);
        free(node);
    }
}

int length_list(Node* list) {
    int n = 0;
    for (Node* node = list; node != NULL; node = node->next) n++;
    return n;
}

bool contains_list(Node* list, Object* element) {
    for (Node* node = list; node != NULL; node = node->next) {
        Object* o = node->value;
        assert_not_null(o);
        if (equal(o, element)) { // compare content
            return true;
        }
    }
    return false;
}

Node* remove_list(Node* list, int index, bool free_element) {
    if (list == NULL || index < 0) return list;
    if (index == 0) { // remove first element of non-empty list
        Node* n = list->next;
        if (free_element) {
            Object* o = list->value;
            assert_not_null(o);
            delete(o);
        }
        free(list);
        return n;
    }
    // return second or later element of non-empty list
    int i = 0;
    for (Node* node = list; node != NULL; node = node->next) {
        if (i + 1 == index) {
            Node* to_remove = node->next;
            if (to_remove == NULL) return list;
            Node* n = to_remove->next;
            if (free_element) {
                Object* o = to_remove->value;
                assert_not_null(o);
                delete(o);
            }
            free(to_remove);
            node->next = n;
            return list;
        }
        i++;
    }
    return list;
}

Node* prepend_list(Object* value, Node* list) {
    require_not_null(value);
    return new_node(value, list);
}

Node* append_list(Node* list, Object* value) {
    if (list == NULL) { // empty list
        return new_node(value, NULL);
    } else { // non-empty list
        Node* n = list;
        while (n->next != NULL) n = n->next; // find last element
        assert("on last element", n != NULL && n->next == NULL);
        n->next = new_node(value, NULL);
        return list;
    }
}

Node* copy_list(Node* list, bool copy_element) {
    if (list == NULL) {
        return NULL;
    } else {
        if (copy_element) { // just reassign, do not copy elements
            Object* o = list->value;
            assert_not_null(o);
            Node* result = new_node(copy(o), NULL);
            for (Node* n = result; list->next != NULL; n = n->next) {
                list = list->next;
                o = list->value;
                assert_not_null(o);
                n->next = new_node(copy(o), NULL);
            }
            return result;
        } else { // copy elements
            Node* result = new_node(list->value, NULL);
            for (Node* n = result; list->next != NULL; n = n->next) {
                list = list->next;
                n->next = new_node(list->value, NULL);
            }
            return result;
        }
    }
}

Node* insert_list(Node* list, int index, Object* value) {
    require("valid index", index >= 0 && index <= length_list(list));
    assert_not_null(value);
    if (index <= 0) { // insert at front
        return new_node(value, list);
    }
    // insert after first element
    Node *node = list;
    int i = 1;
    while (node != NULL && i < index) { // skip index - 1 nodes
        node = node->next;
        i++;
    }
    if (node != NULL) {
        node->next = new_node(value, node->next);
    }
    return list;
}

Node* insert_ordered(Node* list, Object* value, CompFunc compare) {
    require_not_null(value);
    require_not_null(compare);
    if (list == NULL) { // empty list
        return new_node(value, NULL);
    } else if (compare(value, list->value) < 0) { // insert before first
        return new_node(value, list);
    } else { // non-empty list, find insertion position after first node
        for (Node* n = list; n != NULL; n = n->next) {
            if (n->next == NULL) { // end of list?
                n->next = new_node(value, n->next);
                break;
            } else if (compare(value, n->next->value) < 0) { // found position?
                n->next = new_node(value, n->next);
                break;
            }
        }
        return list;
    }
}

Node* reverse_list(Node* list) {
    if (list == NULL) {
        return NULL;
    } else {
        Node* first = list;
        Node* last = list;
        Node* next;
        for (Node* n = list->next; n != NULL; n = next) {
            next = n->next;
            n->next = first;
            first = n;
        }
        last->next = NULL;
        return first;
    }
}

Object* find_list(Node* list, FilterFunc pred, void* x) {
    require_not_null(pred);
    int i = 0;
    for (Node* node = list; node != NULL; node = node->next, i++) {
        if (pred(node->value, i, x)) {
            return node->value;
        }
    }
    return NULL;
}

///////////////////////////////////////////////////////////////////////////

Node* map_list(Node* list, MapFunc f, void* x) {
    require_not_null(f);
    if (list == NULL) return NULL;
    Node* first = new_node(f(list->value, 0, x), NULL);
    Node* last = first;
    int i = 1;
    for (Node* node = list->next; node != NULL; node = node->next, i++) {
        Object* o = f(node->value, i, x); 
        assert_not_null(o);
        last->next = new_node(o, NULL);
        last = last->next;
    }
    return first;
}

Node* filter_list(Node* list, FilterFunc pred, void* x) {
    require_not_null(pred);
    Node* first = NULL;
    Node* last = NULL;
    int i = 0;
    for (Node* node = list; node != NULL; node = node->next, i++) {
        if (pred(node->value, i, x)) {
            if (first == NULL) {
                first = new_node(node->value, NULL);
                last = first;
            } else {
                last->next = new_node(node->value, NULL);
                last = last->next;
            }
        }
    }
    return first;
}

Node* filter_map_list(Node* list, FilterFunc pred, MapFunc map, void* x) {
    require_not_null(pred);
    require_not_null(map);
    Node* result = NULL;
    int i = 0;
    for (Node* node = list; node != NULL; node = node->next, i++) {
        if (pred(node->value, i, x)) {
            Object* o = map(node->value, i, x);
            assert_not_null(o);
            result = new_node(o, result);
        }
    }
    return reverse_list(result);
}

void reduce_list(Node* list, ReduceFunc f, void* state) {
    require_not_null(f);
    int i = 0;
    for (Node* node = list; node != NULL; node = node->next, i++) {
        f(state, node->value, i);
    }
}

