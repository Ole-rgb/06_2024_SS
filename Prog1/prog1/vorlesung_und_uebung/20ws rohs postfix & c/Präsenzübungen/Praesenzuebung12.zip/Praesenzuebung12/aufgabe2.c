/*
Compile: make aufgabe2
Run: ./aufgabe2
make aufgabe2 && ./aufgabe2
*/

#include "base.h"

typedef struct Tree {
    int value;
    struct Tree* left;
    struct Tree* right;
} Tree;

Tree* tnode(Tree* left, int value, Tree* right) {
    Tree* t = xcalloc(1, sizeof(Tree));
    t->value = value;
    t->left = left;
    t->right = right;
    return t;
}

Tree* tleaf(int value) {
    return tnode(NULL, value, NULL);
}

void print_tree(Tree* t) {
    if (t == NULL) {
        printf( "_");
    } else if (t->left == NULL && t->right == NULL) {
        printf( "(%d)", t->value);
    } else {
        printf( "(");
        print_tree(t->left);
        printf( ", %d, ", t->value);
        print_tree(t->right);
        printf( ")");
    }
}

void println_tree(Tree* t) {
    print_tree(t);
    printf("\n");
}

typedef struct IntList {
    int value;
    struct IntList* next;
} IntList;

IntList* lnode(int value, IntList* next) {
    IntList* l = xcalloc(1, sizeof(IntList));
    l->value = value;
    l->next = next;
    return l;
}

void print_list(FILE* f, IntList* list) {
    if (list == NULL) {
        fprintf(f, "[]");
    } else {
        fprintf(f, "[%d", list->value);
        for (IntList* n = list->next; n != NULL; n = n->next) {
            fprintf(f, ", %d", n->value);
        }
        fprintf(f, "]");
    }
}

void fprint_list(String name, IntList* list) {
    FILE* f = fopen(name, "w");
    print_list(f, list);
    fclose(f);
}

void println_list(IntList* list) {
    print_list(stdout, list);
    printf("\n");
}

IntList* level_bintree(Tree* t, int level, IntList* result) {
    return NULL; // todo: implement
}

void test(int line, Tree* t, int level, String expected) {
    IntList* nodes_on_level = level_bintree(t, level, NULL);
    println_tree(t);
    printiln(level);
    println_list(nodes_on_level);
    fprint_list("tmp.txt", nodes_on_level);
    base_test_equal_s(__FILE__, line, s_read_file("tmp.txt"), expected);
}

int main(void) {
    Tree* t = tnode(tleaf(-1), 2, tleaf(3));
    test(__LINE__, t, 0, "[2]");
    test(__LINE__, t, 1, "[-1, 3]");
    test(__LINE__, t, 2, "[]");

    t = tnode(tleaf(-1), 2, tnode(tleaf(4), 3, tleaf(-5)));
    test(__LINE__, t, 0, "[2]");
    test(__LINE__, t, 1, "[-1, 3]");
    test(__LINE__, t, 2, "[4, -5]");
    test(__LINE__, t, 3, "[]");

    t = tnode(tleaf(1), -2, tnode(tnode(tleaf(3), 4, tnode(tleaf(5), 9, NULL)), -7, tleaf(0)));
    test(__LINE__, t, 0, "[-2]");
    test(__LINE__, t, 1, "[1, -7]");
    test(__LINE__, t, 2, "[4, 0]");
    test(__LINE__, t, 3, "[3, 9]");
    test(__LINE__, t, 4, "[5]");
    test(__LINE__, t, 5, "[]");

    return 0;
}
