#include "str.h"
#include "class.h"

Object* copy_str(Object* x);
void delete_str(Object* x);
bool strs_equal(Object* x, Object* y);
String str_to_string(Object* x);

/// Represents a Str object.
typedef struct Str {
    Class* class; ///< pointer to str_class
    String s; ///< the actual C string (a pointer to a zero-terminated char array)
} Str;

static Class str_class;

static Class* get_str_class(void) {
    if (str_class.copy == NULL) {
        str_class.name = "Str";
        str_class.copy = copy_str;
        str_class.delete = delete_str;
        str_class.equal = strs_equal;
        str_class.to_string = str_to_string;
    }
    return &str_class;
}

bool is_str(Object* x) {
    if (x == NULL) return false;
    return x->class == &str_class;
}

Object* new_str(String s) {
    require_not_null(s);
    Str* str = xcalloc(1, sizeof(Str));
    str->class = get_str_class();
    str->s = s_copy(s);
    ensure("correct class", is_str((Object*)str));
    return (Object*)str;
}

Object* copy_str(Object* x) {
    require("correct class", is_str(x));
    Str* str = (Str*)x;
    return new_str(str->s);
}

String str_to_string(Object* x) {
    require("correct class", is_str(x));
    Str* str = (Str*)x;
    return s_copy(str->s);
}

void delete_str(Object* x) {
    require("correct class", is_str(x));
    Str* str = (Str*)x;
    free(str->s);
    free(str);
}

bool strs_equal(Object* x, Object* y) {
    Str* a = (Str*)x;
    Str* b = (Str*)y;
    if (a == b) return true;
    if (a == NULL || b == NULL) return false;
    if (a->class != b->class) return false;
    require("correct class", is_str(x));
    require("correct class", is_str(y));
    return s_equals(a->s, b->s);
}

int compare_strs(Object* x, Object* y) {
    Str* a = (Str*)x;
    Str* b = (Str*)y;
    if (a == b) return 0;
    if (a == NULL) return -1;
    if (b == NULL) return 1;
    require("correct class", is_str(x));
    require("correct class", is_str(y));
    return strcmp(a->s, b->s);
}
