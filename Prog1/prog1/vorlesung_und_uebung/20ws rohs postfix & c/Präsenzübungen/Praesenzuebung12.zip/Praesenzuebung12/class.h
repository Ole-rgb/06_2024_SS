/** @file
A Class contains pointers to class-specific functions and the name of the class.
Morover, this module contains type definitions for these function types. If you
implement a new kind of object, each of these functions has to be implemented
and a singleton Class structure instance has to be defined, which points to
these implementations.

@author Michael Rohs
@date 07.01.2021
@copyright Apache License, Version 2.0
*/

#ifndef CLASS_H_INCLUDED
#define CLASS_H_INCLUDED

#include "object.h"

/// Represents the class of an object. For each type  of object there is a single
/// class instance.
typedef struct Class Class;

/// Function type for copying an object.
typedef Object* (*CopyFunc)(Object* object);

/// Function type for deleting an object.
typedef void (*DeleteFunc)(Object* object);

/// Function type for checking if two objects are equal.
typedef bool (*EqualFunc)(Object* object1, Object* object2);

/// Function type for creating a dynamically allocated string representation 
/// of the object, which the caller has to release.
typedef String (*ToStringFunc)(Object* object);

/// Represents the class of an object. For each type  of object there is a single
/// class instance.
struct Class {
    String name; ///< the name of the class
    CopyFunc copy; ///< a pointer to the copy function
    DeleteFunc delete; ///< a pointer to the delete function
    EqualFunc equal; ///< a pointer to the equality-check function
    ToStringFunc to_string; ///< a pointer to the to-string function
};

/**
Represents an individual object.
The first element of each object is a pointer to its class.
All objects of the same class have the same class-pointer value.
*/
struct Object {
    Class* class; ///< the class of the object (identical for all objects of the same class)
};

#endif
