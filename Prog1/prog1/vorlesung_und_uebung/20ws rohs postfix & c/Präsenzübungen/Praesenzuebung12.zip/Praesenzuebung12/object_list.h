/** @file
An ObjectList is a list of Object pointers.

@note The documentation of the functions is not complete. Details on parameters,
return values, preconditions, and postconditions are missing.

@author Michael Rohs
@date 07.01.2021
@copyright Apache License, Version 2.0
*/

#ifndef OBJECT_LIST_H_INCLUDED
#define OBJECT_LIST_H_INCLUDED

#include "base.h"
#include "object.h"

/// Represents a single list node.
typedef struct Node Node;

/// Creates a list node.
Node* new_node(Object* value, Node* next);

/// Prints the elements of the given list. Uses to_string to print an element.
void print_list(Node* list);

/// Prints list followed by a newline. Uses to_string to print an element.
void println_list(Node* list);

/// Frees all nodes of the list. Uses free_element to free an element.
/// If free_element is NULL, does not free the elements.
void free_list(Node* list, bool free_element);

/// Number of elements of the list.
int length_list(Node* list);

/// Checks whether list contains element. Uses equal 
/// to compare elements. If equal is NULL compares pointers.
bool contains_list(Node* list, Object* element);

/// Removes element at position index from list. Uses free_element to release the element.
/// If free_element is NULL, do not release the element.
Node* remove_list(Node* list, int index, bool free_element);

/// Prepends an element in front of the list.
Node* prepend_list(Object* value, Node* list);

/// Adds an element to the end of the list. Modifies the existing list.
Node* append_list(Node* list, Object* value);

/// Copies the list. Uses copy_element to copy each element.
/// If copy_element is NULL, just assigns the pointer to the original element.
Node* copy_list(Node* list, bool copy_element);

/// Insert value in list at index.
Node* insert_list(Node* list, int index, Object* value);

/// Returns =0 if x and y are equal, <0 if x smaller than y, >0 otherwise.
typedef int (*CompFunc)(Object* x, Object* y);

/// Inserts value at the right position. Uses cmp to compare elements.
Node* insert_ordered(Node* list, Object* value, CompFunc cmp);

/// Reverses the origial list.
Node* reverse_list(Node* list);

/// Checks whether element satisfies a predicate.
typedef bool (*FilterFunc)(Object* element, int i, void* x);

/// Finds the first element in list for which pred(element, i, x) is true.
Object* find_list(Node* list, FilterFunc pred, void* x);

///////////////////////////////////////////////////////////////////////////////

/// Transforms element into something else.
typedef Object* (*MapFunc)(Object* element, int i, void* x);

/// Maps each list element to f(element, index, x).
Node* map_list(Node* list, MapFunc f, void* x);

/// Produces a list of those elements of list that satisfy the predicate.
Node* filter_list(Node* list, FilterFunc predicate, void* x);

/// First filters list using predicate and then maps the filtered elements using map.
Node* filter_map_list(Node* list, FilterFunc predicate, MapFunc map, void* x);

/// Aggregates a list: state is the intermediary aggregation result, element is the current element.
typedef void (*ReduceFunc)(void* state, Object* element, int index);

/// Aggregates the list using f. Modifies state.
void reduce_list(Node* list, ReduceFunc f, void* state);

#endif
