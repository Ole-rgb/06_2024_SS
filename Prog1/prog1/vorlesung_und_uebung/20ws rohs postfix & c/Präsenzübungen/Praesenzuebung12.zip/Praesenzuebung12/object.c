#include "class.h"

String class_name(Object* o) {
    require_not_null(o);
    return o->class->name;
}

Object* copy(Object* o) {
    require_not_null(o);
    return o->class->copy(o);
}

void delete(Object* o) {
    require_not_null(o);
    o->class->delete(o);
}

bool equal(Object* o1, Object* o2) {
    if (o1 == o2) return true; // same object or both NULL?
    if (o1 == NULL || o2 == NULL) return false; // one NULL, but not the other?
    if (o1->class != o2->class) return false; // different classes?
    return o1->class->equal(o1, o2);
}

String to_string(Object* o) {
    require_not_null(o);
    return o->class->to_string(o);
}

