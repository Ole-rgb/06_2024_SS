#include "base.h"

int main(void) {
	printsln("Rate meine Zahl, sie liegt im Intervall [0, 100]");
	int number = i_rnd(101);
	int i = 0;
while (i == 0) {
		int guess = i_input();
		if (guess > number) {
			printsln("Zahl zu gross!");
		} else if (guess < number) {
			printsln("Zahl zu klein!");
		} else if (guess == number) {
			printsln("Zahl korrekt!");
			i = 1;
		}	
}

	return 0;
}
