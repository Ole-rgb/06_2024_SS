#include base.h

int main(void) {
	int number = i_rnd(100);

	return 0;
}