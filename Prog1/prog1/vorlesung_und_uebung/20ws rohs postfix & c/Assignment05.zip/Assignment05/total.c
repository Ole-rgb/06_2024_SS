/*
Compile: make total-solution
Run: ./total-solution
make total-solution && ./total-solution
*/

#include "base.h"


//todo: define constants 
const int PREIS1 = 50; 
const int PREIS2 = 45;
const int PREIS3 = 40;
const int GRENZE = 2000;
const int VERSAND = 500; 


//todo: Write function total
int total(int anzahl) {
	int gesamtpreis;

	//Test (positive Anzahl)
	if(anzahl <= 0) return 0;

	//Berechnung des Preises
	if(anzahl < 10) {
		gesamtpreis = anzahl * PREIS1;
	}
	if(anzahl >= 10) {
		gesamtpreis = anzahl * PREIS2;
	}
	if(anzahl >= 100) {
		gesamtpreis = anzahl * PREIS3;
	}

	//Berechnung Versandkosten
	if(gesamtpreis < GRENZE) gesamtpreis += 500;

	return gesamtpreis;
}


//todo: Write function total_test
void total_test() {
	test_equal_i(total(-1), 0);
	test_equal_i(total(9), 950);
	test_equal_i(total(99), 4455);
	test_equal_i(total(11), 995);
	test_equal_i(total(101), 4040);
}


int main (void){

	//todo: call total_test Function
	total_test();
}