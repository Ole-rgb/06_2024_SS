/*
Compile: make secret_message
Run: ./secret_message
*/

#include "base.h"

//todo: Write decode method
String decode(String s) {
	int length = s_length(s);
	String result = s_copy(s);

	for(int i = 0; i < length; i++) {
		char temp = s_get(result, i);

		if (temp > '@' && temp < '[') {
			temp = 'Z' - (temp - 'A');
		} else if ( temp > '`' && temp < '{') {
			temp = 'z' - (temp - 'a');
		}

		s_set(result, i, temp);
	}
	return result;
}

//todo: Write test method for decode

//todo: Write encode method
String encode(String s) {
   	return  s = decode(s);
}

//todo: Write test method for encode

int main(void){
	//todo: Decode this message to get a hint for part c) + d)
	String secret_message = "Kiltiznnrvivm 1 nzxsg Hkzhh. Wrvh rhg pvrmv Dviyfmt ufvi vgdzrtv Kilwfpgv zfu wvn Yrow. Grkk: Wrv Olvhfmt ufvi wzh vmxlwrvivm rhg tzma vrmuzxs fmw kzhhg rm vrmv Avrov.";
	
	printsln(decode(secret_message));
	printsln(encode(decode(secret_message)));
	
	//call test functions

	return 0;
}