#include "base.h"
/*
    make rects
    ./rects
    make rects && ./rects
*/

enum FillProperty{
    RANGE,
    SIMPLE,
    PATTERN
} typedef TFillProperty;

struct RangeFill{
    char start;
    char end;
} typedef RangeFill;

struct SimpleFill{
    char c;
} typedef SimpleFill;

struct PatternFill{
    String pattern;
} typedef PatternFill;

struct Fill{
    TFillProperty tag;
    union{
        PatternFill pf;
        SimpleFill sf;
        RangeFill rf;  
    };
}typedef Fill;

struct Rect{
    int x, y;
    int width, height;
    Fill fill;    
} typedef Rect;

Fill make_range_fill(char lower, char upper){
    //todo:
    require("valid input", lower <= upper);
    require("valid input", lower >= 1 && lower <= 127);
    require("valid input", upper >= 1 && upper <= 127);
    Fill fill;
    fill.tag = RANGE;
    fill.rf.start = lower;
    fill.rf.end = upper;
    return fill;
}

Fill make_pattern_fill(String s){
    require("valid input", s_length(s) > 0);
    Fill fill;
    fill.tag = PATTERN;
    fill.pf.pattern = s;
    return fill;
}

Fill make_simple_fill(char c){
    //todo:
    require("valid input", c >= 1 && c <= 127);
    require("valid input", isprint(c) != 0);
    Fill fill;
    fill.tag = SIMPLE;
    fill.sf.c = c;
    return fill;
    
}

Rect make_rect(int x, int y, int width, int height, Fill fill){
    //todo:
    require("valid input", x >= 0 && y >= 0 && width >= 0 && height >= 0);
    require("valid input", fill.tag == PATTERN || fill.tag == RANGE || fill.tag == SIMPLE);
    Rect rect;
    rect.x = x;
    rect.y = y;
    rect.width = width;
    rect.height = height;
    rect.fill = fill;

    return rect;
}    

void draw_rect(Rect rect){
    //todo:
    //Koordinaten
    for(int i = 0; i < rect.y; i++) {
      printf("\n");
    } 
    for(int i = 0; i < rect.x; i++) {
      printf(" ");
    }

    //Deckel
    printf("+");
    for(int i = 2; i < rect.width; i++) {
      printf("-");
    }
    printf("+\n");

    //Körper
    if(rect.fill.tag == SIMPLE) {
      for(int i = 2; i < rect.height; i++) {
        for(int i = 0; i < rect.x; i++) {
          printf(" ");
        }
        printf("|");
        for(int i = 2; i < rect.width; i++) {
          printf("%c", rect.fill.sf.c);
        }
        printf("|\n");
      }

    } else if(rect.fill.tag == RANGE) {
      char number = rect.fill.rf.start;
      char limit = rect.fill.rf.end;

      for(int i = 2; i < rect.height; i++) {
        for(int i = 0; i < rect.x; i++) {
          printf(" ");
        }
        printf("|");
        for(int i = 2; i < rect.width; i++) {
          if(number > limit) number = rect.fill.rf.start;
          printf("%c", number);
          number++;
        }
        printf("|\n");
      }

    }else if(rect.fill.tag == PATTERN) {
      int limit = s_length(rect.fill.pf.pattern);
      int symb = 0;
      String s = rect.fill.pf.pattern;

      for(int i = 2; i < rect.height; i++) {
        for(int i = 0; i < rect.x; i++) {
          printf(" ");
        }
        printf("|");
        for(int i = 2; i < rect.width; i++) {
          if(symb == limit) symb = 0;
          printf("%c", s[symb]);
          symb++;
        }
        printf("|\n");
      }
    }

  //Boden
  for(int i = 0; i < rect.x; i++) {
    printf(" ");
  }
  printf("+");
  for(int i = 2; i < rect.width; i++) {
    printf("-");
  }
  printf("+\n");
}
/*
width = 1, height = 1
+

width = 1, height = 2
+
+

width = 2, height = 1
++

width = 2, height = 2
++
++

width = 3, height = 2
+-+
+-+

width = 3, height = 3, x = 1, y = 0, fill = simple with 'o'

 +-+
 |o|
 +-+
 
width = 15, height = 10, x = 15, y = 0, fill = pattern with ".o"
               +-------------+
               |.o.o.o.o.o.o.|
               |o.o.o.o.o.o.o|
               |.o.o.o.o.o.o.|
               |o.o.o.o.o.o.o|
               |.o.o.o.o.o.o.|
               |o.o.o.o.o.o.o|
               |.o.o.o.o.o.o.|
               |o.o.o.o.o.o.o|
               +-------------+
*/
int main(void) {
    // Mindestens 6 verschiedene Rechtecke mit unterschiedlichen Position, Fuellungen und Groeßen.
    draw_rect(make_rect(1, 1, 4, 5, make_simple_fill('o')));
    draw_rect(make_rect(1, 1, 4, 5, make_range_fill('0', '3')));
    draw_rect(make_rect(1, 1, 7, 7, make_pattern_fill(".o")));
    return 0;
}