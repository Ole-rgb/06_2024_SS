/*
Compile: make people
Run: ./people
*/

#include "base.h"
#include "string.h"

// a) struct Statistics ...
struct Stats {
	//Durchschnittliches Geburtsjahr
	int dGJahr;
	//Anzahl
	int anzahlMänner;
	int anzahlFrauen;
	//Durchschnittliche Köpergrößen
	double dKMänner;
	double dKFrauen;
};
typedef struct Stats Stats;

// b) ... make_statistics...
Stats make_statistics(void) {
	Stats result = {0, 0, 0, 0.00, 0.00};
	return result;
}

// c) ... print_statistics...
void print_statistics(Stats s) {
	printf("mean year:\t\t%4d\n", s.dGJahr);
	printf("number males:\t\t%4d\n", s.anzahlMänner);
	printf("number females:\t\t%4d\n", s.anzahlFrauen);
	printf("mean height males:\t%3.2f m\n", s.dKMänner); 
	printf("mean height females:\t%3.2f m\n", s.dKFrauen);
}

// d) ... compute_statistics...
Stats compute_statistics(String table) {
	Stats result = make_statistics();
	//Daten zusammensuchen
	//indikatoren
	int i = 0, j = 0;
	int n = s_length(table);
	
	//Geburtsjahr
	while(s_get(table, i) != '\n') i++;
	while(i < n) {
		j = i;
		while(j < n && s_get(table, j) != '\t') j++;
		int year = i_of_s(s_sub(table, i, j));
		result.dGJahr += year;

	i = j + 1;

	//Gender
	char sex = s_get(table, i);
	if(sex == 'm') result.anzahlMänner++;
	else result.anzahlFrauen++;

	i += 2;
	j = i;

	//Körpergröße
	while(j < n && s_get(table, j) != '\n') j++;
	double height = d_of_s(s_sub(table, i ,j));
	if(sex == 'm') result.dKMänner += height;
	else if(sex == 'f') result.dKFrauen += height;
	i = j + 1;
	} 

	//Berechnung
	result.dGJahr /= result.anzahlFrauen + result.anzahlMänner;
	result.dKMänner /= result.anzahlMänner;
	result.dKFrauen /= result.anzahlFrauen;

	return result;
}


int main(void) {
	String table = s_read_file("people.txt");
	printsln(table);
	Stats request = compute_statistics(table);
	print_statistics(request);
	return 0;
}
