/*
Compile: make volume
Run: ./volume
make volume && ./volume
*/
#define _USE_MATH_DEFINES
#define _GNU_SOURCE
#include "base.h"

enum Tag { TCylinder, TSphere, TCuboid };
typedef enum Tag Tag;

struct Cylinder {
    double r, h; // V = pi * r^2 * h
};

struct Sphere {
    double r; // V = 4 / 3 * pi * r^3
};

struct Cuboid {
    double a, b, c; // V = a * b *c
};

struct GeomObject {
    // todo: implement
   Tag tag;
   struct Cylinder cylinder;
   struct Sphere sphere;
   struct Cuboid cuboid;
};

typedef struct Cylinder Cylinder;
typedef struct Sphere Sphere;
typedef struct Cuboid Cuboid;
typedef struct GeomObject GeomObject;

GeomObject make_cylinder(double r, double h) {
    // todo: implement
    require("no negative", r && h >= 0);
    GeomObject o;
    o.tag = TCylinder;
    o.cylinder.r = r;
    o.cylinder.h = h;
    return o;
}

GeomObject make_sphere(double r) {
    // todo: implement
    require("no negative", r >= 0);
    GeomObject o;
    o.tag = TSphere;
    o.sphere.r = r;
    return o;
}

GeomObject make_cuboid(double a, double b, double c) {
    // todo: implement
    require("no negative", a && b && c >= 0);
    GeomObject o;
    o.tag = TCuboid;
    o.cuboid.a = a;
    o.cuboid.b = b;
    o.cuboid.c = c;
    return o;
}

double volume(GeomObject o);

void volume_test(void) {
    test_within_d(volume(make_sphere(2)), 4 /3.0 * M_PI * 2 * 2 * 2, 1e-6);
    test_within_d(volume(make_cuboid(2, 3, 4)), 2 * 3 * 4, 1e-6);
    test_within_d(volume(make_cylinder(3, 4)), 4 * M_PI * 3 * 3 , 1e-6);
}
    
// GeomObject -> double
// Computes the volume of the given object.
double volume(GeomObject o) {
    // todo: implement
    double result;
    switch(o.tag) {
        case TCylinder: result = M_PI * (o.cylinder.r * o.cylinder.r) * o.cylinder.h; break;
        case TSphere: result = 4 / 3 * M_PI * (o.sphere.r * o.sphere.r * o.sphere.r); break;
        case TCuboid: result = o.cuboid.a * o.cuboid.b * o.cuboid.c; break;
    }
	return result;
}

int main(void) {
    volume_test();
    return 0;
}

//todo: d)
