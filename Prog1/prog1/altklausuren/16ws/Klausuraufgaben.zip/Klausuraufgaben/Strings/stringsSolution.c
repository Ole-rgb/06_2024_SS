

#include "base.h"
#include "string.h"



/**
(a) Todo: Implement. Nicht so wichtig.
Return whether String a contains String b
*/
bool contains(String a, String b) {
    return false;
}

/**
(b) Todo: Implement. Nicht so wichtig.
Return the result of the evaluation (AND) of the bool expressions included in the string
*/
bool bool_expr_and(String a) {
    return false;
}

/**
(c) Todo: Implement.
Gebe die länge der längsten vorkommenden Sequenz aus.
MÖGLICHE KLAUSURAUFGABE  
*/
int longest_sequence_count(String s, char c){
    int max = 0;
    int counter = 0;
    for(int i = 0; i < s_length(s); i++){
        if(s[i] == c)
            counter++;
        else
            counter = 0;
        
        if(counter > max)
            max = counter;
        
    }
    
    return max;
}

/** (d) MÖGLICHE KLAUSURAUFGABE
 */

bool ends_with_digit(String s){
        
    if(s[s_length(s)-1] >= '0' && s[s_length(s)-1] <= '9')
        return true;
    
    return false;
}

/** (e) Mögliche Klausuraufgabe
 */
int count_double_chars(String s){
    int result = 0;
    
    if(s_length(s) == 2){
        if(s[0] == s[1])
            return 1;
    }else if(s_length(s) < 2)
        return 0;
    
    int counter = 0;
    char prev;
    for(int i = 0; i < s_length(s); i++){
    
       if(counter == 0){
            prev = s[i];
            counter++;
       }
       else if(counter > 0 && s[i] == prev){ //summiere sequenzen
            counter++;
            printf("%c", prev);
            if(counter == 2 && i < s_length(s)-1){
                if(s[i+1] != prev){
                    result++;
                    counter = 0;
                    printf("%c", prev);
                    
                }
                    
            }else if(counter == 2 && i == s_length(s)-1){
                result++;
                
            }
       }else{
           prev = s[i];
           counter = 1;
       }
       
       
       
        
    }
    
    return result;
}





void test(void) {
    // (a)
    /* nicht so wichtig:
    check_expect_i(contains("abc", "b"), true);
    check_expect_i(contains("abc", "ac"), false);
    check_expect_i(contains("Das ist ein t?st.", "test"), true);
    check_expect_i(contains("Das ist ein test.", "Dass"), false);

    
    // (b)
    check_expect_i(bool_expr_and("abc1"), true);
    check_expect_i(bool_expr_and("0abc1"), false);
    check_expect_i(bool_expr_and("Das 1st ein Test 0der?"), false);
    */
    
    // (c)
    check_expect_i(longest_sequence_count("Hello World!", 'l'), 2);
    check_expect_i(longest_sequence_count("Roffffflcopterf!", 'f'), 5);
    check_expect_i(longest_sequence_count("Hello World!", 'q'), 0);
    
    // (d)
    check_expect_i(ends_with_digit("Das ist ein Test"), false);
    check_expect_i(ends_with_digit("Das ist ein Test 12345"), true);
    check_expect_i(ends_with_digit("5"), true);
    check_expect_i(ends_with_digit("a"), false);
    
    // (e)
    check_expect_i(count_double_chars("Hello World!"), 1);
    check_expect_i(count_double_chars("Helllo World!"), 0);
    check_expect_i(count_double_chars("aaaa"), 0);
    check_expect_i(count_double_chars("aabbcc"), 3);
    check_expect_i(count_double_chars("abccc"), 0);
    check_expect_i(count_double_chars("aabcc"), 2);
    check_expect_i(count_double_chars("a"), 0);
    check_expect_i(count_double_chars(""), 0);
    
}

int main(void) {
    test();
    return 0;
}
