public class Abaum {

	private class Node {

			public String value;
			public Node[] nodes;

			public Node(String value) {
				this.value = value;
			}

			//Berechnet die Funktion aus dem arithmetischem Baum
			public int function() {       
				// todo: implement
			}
				

	}

    public Node root;

    public Abaum(Node root) {
        this.root = root;
    }
	
	public Abaum() {
    }
    
    public int function() {
		if(this.root == null)
			return 0;
    	else
			return this.root.function();
    }
	
	public void addNodes() {
        this.root = new Node("+");
		
        this.root.nodes = new Node[3];
    	this.root.nodes[0] = new Node("3");
    	this.root.nodes[1] = new Node("*");
    	this.root.nodes[2] = new Node("+");
		
        this.root.nodes[1].nodes = new Node[3];
    	this.root.nodes[1].nodes[0] = new Node("print");
    	this.root.nodes[1].nodes[1] = new Node("7");
        this.root.nodes[1].nodes[2] = new Node("2");
		
        this.root.nodes[2].nodes = new Node[2];
    	this.root.nodes[2].nodes[0] = new Node("4");
    	this.root.nodes[2].nodes[1] = new Node("print");
		
        this.root.nodes[1].nodes[0].nodes = new Node[1];
        this.root.nodes[1].nodes[0].nodes[0]= new Node("+");
        this.root.nodes[1].nodes[0].nodes[0].nodes = new Node[2];
        this.root.nodes[1].nodes[0].nodes[0].nodes[0] = new Node("3");
        this.root.nodes[1].nodes[0].nodes[0].nodes[1] = new Node("4");
        
        this.root.nodes[2].nodes[1].nodes = new Node[1];
        this.root.nodes[2].nodes[1].nodes[0] = new Node("3");
		
	}
	
    
    public static void main(String[] args) {
		Abaum t = new Abaum();
		t.addNodes();
		String s = "" + t.function();
		System.out.println(s);
    }
    
}
