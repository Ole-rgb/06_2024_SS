import prog1.base.Base;

// Windows:
// javac -cp .;prog1javalib.jar BinarySearchTree.java
// java -cp .;prog1javalib.jar BinarySearchTree

// OS X:
// javac -cp .:prog1javalib.jar BinarySearchTree.java
// java -cp .:prog1javalib.jar BinarySearchTree

public class BinarySearchTree {
    
    private class Node {
        private int value;
        private Node left, right;
        
        private Node(int value, Node left, Node right) {
            this.left = left;
            this.value = value;
            this.right = right;
        }

        private void add(int i) {
            if (i < value) {
                if (left == null) {
                    left = new Node(i, null, null); 
                } else {
                    left.add(i);
                }
            } else { // n >= value
                if (right == null) {
                    right = new Node(i, null, null); 
                } else {
                    right.add(i);
                }
            }
        }
        
        private int size() {
		//todo: implement
        }
        
        private boolean contains(int i) {
			//todo: implement
        }
        
        private int numberOfLeaves() {
			//todo: implement
        }
        
        private int nearest(int target, int nearestSoFar) {
			//todo: implement
        }
        
		

        
        public String toString() { 
            if (left == null && right == null) {
                return String.valueOf(value);
            }
            return "(" + (left != null ? left : "_") + 
                    "," + value + "," + 
                    (right != null ? right : "_") + ")";
        }

    } // class Node
    
    private Node root = null;

    public void add(int i) {
        if (root == null) {
            root = new Node(i, null, null); 
        } else {
            root.add(i);
        }
    }   
    
    public int size() { 
        if (root == null) {
            return 0;
        } else {
            return root.size();
        }
    }
    
    public boolean contains(int i) { 
        if (root == null) {
            return false;
        } else {
            return root.contains(i); 
        }
    }
    
    public int numberOfLeaves() {
        if (root == null) {
            return 0;
        } else {
            return root.numberOfLeaves();
        }
    }

    public String toString() {
        if (root == null) {
            return "()";
        } else {
            return root.toString();
        }
    }

    public int nearest(int value) {
        if (root == null) {
            return Integer.MAX_VALUE;
        } else {
            return root.nearest(value, Integer.MAX_VALUE);
        }
    }
    
    private static void test() {
        BinarySearchTree tree = new BinarySearchTree();
        int[] values = {1, 3, -3, -64, 11, 50, -52, 24, -43, 37};
        for (int v  : values) {
            tree.add(v);
        }
        //   Tree structure
        //          1
        //     -3       3
        // -64              11
        //    -52               50
        //  -43               24
        //                      37
        Base.println(tree);
        Base.checkExpect(tree.contains(values[2]), true);
        Base.checkExpect(tree.contains(values[2] + 1000), false);
        Base.checkExpect(tree.size(), values.length);
        Base.checkExpect(tree.numberOfLeaves(), 2);
        Base.checkExpect(tree.nearest(3), 3);
        Base.checkExpect(tree.nearest(36), 37);
        Base.checkExpect(tree.nearest(0), 1);
        Base.checkExpect(tree.nearest(-100), -64);
        Base.summary();
        
        //System.out.println(tree.levelOrder());
    }
    
    public static void main(String[] args) {
        test();
    }
}
