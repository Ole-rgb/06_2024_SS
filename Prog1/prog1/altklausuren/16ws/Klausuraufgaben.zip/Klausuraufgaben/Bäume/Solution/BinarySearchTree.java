import prog1.base.Base;

// Windows:
// javac -cp .;prog1javalib.jar BinarySearchTree.java
// java -cp .;prog1javalib.jar BinarySearchTree

// OS X:
// javac -cp .:prog1javalib.jar BinarySearchTree.java
// java -cp .:prog1javalib.jar BinarySearchTree

public class BinarySearchTree {
    
    private class Node {
        private int value;
        private Node left, right;
        
        private Node(int value, Node left, Node right) {
            this.left = left;
            this.value = value;
            this.right = right;
        }

        private void add(int i) {
            if (i < value) {
                if (left == null) {
                    left = new Node(i, null, null); 
                } else {
                    left.add(i);
                }
            } else { // n >= value
                if (right == null) {
                    right = new Node(i, null, null); 
                } else {
                    right.add(i);
                }
            }
        }
        
        private int size() {
			if(this.left != null && this.right != null){
				return this.left.size() + this.right.size() + 1;
			}else if(this.left != null){
				return this.left.size() + 1;
			}else if(this.right != null){
				return this.right.size() + 1;
			}
            return 1; // todo: implement
        }
        
        private boolean contains(int i) {
			if(i == this.value){
				return true;
			}else if(i < this.value){
				if(this.left != null)
					return left.contains(i);
			}else{
				if(this.right != null)
					return right.contains(i);
			} 			
            return false; // todo: implement
        }
        
        private int numberOfLeaves() {
			if(this.left != null && this.right != null)
				return this.left.numberOfLeaves() + this.right.numberOfLeaves();
			else if(this.left != null)
				return this.left.numberOfLeaves();
			else if(this.right != null)
				return this.right.numberOfLeaves();
				
            return 1; // todo: implement
        }
        
        private int nearest(int target, int nearestSoFar) {
			if(target == this.value)
				return this.value;
			else{
				
				if(this.left != null && this.right != null){
					
					if(Math.abs(this.left.value - target) < Math.abs(this.right.value-target)
					&& Math.abs(this.left.value - target) < Math.abs(this.value - target))
						return this.left.nearest(target, this.left.value);
					else if(Math.abs(this.right.value - target) < Math.abs(this.left.value-target)
						 && Math.abs(this.right.value - target) < Math.abs(this.value - target))
						return this.right.nearest(target, this.right.value);
					else
						return this.value;
						
				}else if(this.left != null){
				
					if(Math.abs(this.left.value - target) < Math.abs(this.value - target))
						return this.left.nearest(target, this.left.value);
					else
						return this.value;
						
				}else if(this.right != null){
				
					if(Math.abs(this.right.value - target) < Math.abs(this.value - target))
						return this.right.nearest(target, this.right.value);
					else
						return this.value;
				
				}
			}
            return this.value; // todo: implement
        }
        

        
        public int deep(){
            if(left != null && right != null)
                return 1 + Math.max(left.deep(),right.deep());
            else if(left != null)
                return left.deep() + 1;
            else if(right != null)
                return right.deep() + 1;
                
            return 0;
        }
        
        public String toString() { 
            if (left == null && right == null) {
                return String.valueOf(value);
            }
            return "(" + (left != null ? left : "_") + 
                    "," + value + "," + 
                    (right != null ? right : "_") + ")";
        }

    } // class Node
    
    private Node root = null;

    public int deep(){
        if(root == null)
            return 0;
        else        public String preOrder(){
            String result = value + " ";
            if(left != null && right != null)
                result += left.levelOrder() + right.levelOrder();
            else if(left != null)
                result +=  left.levelOrder();
            else if(right != null)
                result += right.levelOrder();
                
            return result;
        }
            return root.deep();
    }
    public void add(int i) {
        if (root == null) {
            root = new Node(i, null, null); 
        } else {
            root.add(i);
        }
    }   
    
    public int size() { 
        if (root == null) {
            return 0;
        } else {
            return root.size();
        }
    }
    
    public boolean contains(int i) { 
        if (root == null) {
            return false;
        } else {
            return root.contains(i); 
        }
    }
    
    public int numberOfLeaves() {
        if (root == null) {
            return 0;
        } else {
            return root.numberOfLeaves();
        }
    }

    public String toString() {
        if (root == null) {
            return "()";
        } else {
            return root.toString();
        }
    }

    public int nearest(int value) {
        if (root == null) {
            return Integer.MAX_VALUE;
        } else {
            return root.nearest(value, Integer.MAX_VALUE);
        }
    }
    
    private static void test() {
        BinarySearchTree tree = new BinarySearchTree();
        int[] values = {1, 3, -3, -64, 11, 50, -52, 24, -43, 37};
        for (int v  : values) {
            tree.add(v);
        }
        //   Tree structure
        //          1
        //     -3       3
        // -64              11
        //    -52               50
        //  -43               24
        //                      37
        Base.println(tree);
        Base.checkExpect(tree.contains(values[2]), true);
        Base.checkExpect(tree.contains(values[2] + 1000), false);
        Base.checkExpect(tree.size(), values.length);
        Base.checkExpect(tree.numberOfLeaves(), 2);
        Base.checkExpect(tree.nearest(3), 3);
        Base.checkExpect(tree.nearest(36), 37);
        Base.checkExpect(tree.nearest(0), 1);
        Base.checkExpect(tree.nearest(-100), -64);
        
        Base.checkExpect(tree.deep(), 6);
        Base.summary();
        
        //System.out.println(tree.levelOrder());
    }
    
    public static void main(String[] args) {
        test();
    }
}
