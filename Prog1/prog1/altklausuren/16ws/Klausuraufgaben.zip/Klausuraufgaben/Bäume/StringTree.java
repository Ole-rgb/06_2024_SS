import prog1.base.Base;

// Windows:
// javac -cp .;prog1javalib.jar BinarySearchTree.java
// java -cp .;prog1javalib.jar BinarySearchTree

// OS X:
// javac -cp .:prog1javalib.jar BinarySearchTree.java
// java -cp .:prog1javalib.jar BinarySearchTree

public class StringTree {
    
    private static class Node {
        private String value;
        private Node left, right;
        
        private Node(String value, Node left, Node right) {
            this.left = left;
            this.value = value;
            this.right = right;
        }
        
		//String in symmetischer Ordnung ausgeben
        private String buildString(){
			return "";
        }
        

    } // class Node
    
    private Node root = null;

	
    private static void test() {
        StringTree tree = new StringTree();
        tree.root = new Node("foo", new Node("bar", new Node("1", null, null), new Node("5", null, null)), new Node("buz", null, null));
        
        //   Tree structure
        //          foo
        //     bar       buz
        // 1       5            
       
        
		Base.checkExpect(tree.root.buildString(), "1 bar 5 foo buz");
        Base.summary();
        
    }
    
    public static void main(String[] args) {
        test();
    }
}
