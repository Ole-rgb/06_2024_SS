/* Compile:
 * (Mac OS X)
 * gcc -Wall -Werror -ferror-limit=1 -o DistSecondSmallestToSmallest DistSecondSmallestToSmallest.c
 * bzw. (Linux)
 * gcc -Wall -Werror -std=c99 -o DistSecondSmallestToSmallest DistSecondSmallestToSmallest.c
 * 
 * Run:
 * ./DistSecondSmallestToSmallest
 */

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>

typedef struct Node {
	double value;
	struct Node *next;
} Node;

typedef struct List {
	Node *first;
	Node *last;
} List;

List *newList(void) {
	return calloc(1, sizeof(List));
}

Node *newNode(double value) {
	Node *node = calloc(1, sizeof(Node));
	node->value = value;
	return node;
}

void print(List *list) {
	printf("[");
	for (Node *node = list->first; node != NULL; node = node->next) {
		printf("%g", node->value);
		if (node->next != NULL) {
			printf(" ");
		}
	}
	printf("]\n");
}

void append(List *list, double value) {
	Node *p = newNode(value);
	if (list->last != NULL) list->last->next = p;
	list->last = p;
	if (list->first == NULL) list->first = p;
}

/*
 * Create a list from the given string.
 * Use "," (with surrounding whitespace) as the separator.
 * Example: toList("1, 2.5, -3.2, 49.1") --> [1.0 2.5 -3.2 49.1]
 */
List *toList(char *s) {
	List *list = newList();
	char *t = s;
	char *endp;
	while (*t != '\0') {
		if (isdigit(*t)) {
			if (t > s && *(t - 1) == '.') t--; // check for '.'
			if (t > s && *(t - 1) == '-') t--; // check for '-'
			append(list, strtod(t, &endp)); // convert digit string to double
			t = endp;
		} else {
			// assert: *t is not a digit, *t is not '\0'
			t++; // not a digit, skip
		}
	}
	return list;
}

/* Gibt die absolute Differenz zwischen dem kleinsten und dem zweitkleinsten 
 * Element zurückgeben. Gibt 0 bei einer zu kurzen Liste zurück. */
double distSecondSmallestToSmallest(List *list) {
	return 0.0; // todo: implement
}

int check_within(int line, double actual, double expected, double delta) {
	if (fabs(actual - expected) <= delta) {
		printf("line %d: check passed\n", line);
		return 1;
	} else {
		printf("line %d: actual value %g is not within %g of expected value %g.\n", 
			line, actual, delta, expected);
		return 0;
	}
}

int tests(void) {
	check_within(__LINE__, distSecondSmallestToSmallest(toList("")), 0.0, 0.000001);
	check_within(__LINE__, distSecondSmallestToSmallest(toList("1.5")), 0.0, 0.000001);
	check_within(__LINE__, distSecondSmallestToSmallest(toList("1.2, 1.2")), 0.0, 0.000001);
	check_within(__LINE__, distSecondSmallestToSmallest(toList("1.5, 3.0")), 1.5, 0.000001);
	check_within(__LINE__, distSecondSmallestToSmallest(toList("2.2, 1.1")), 1.1, 0.000001);
	check_within(__LINE__, distSecondSmallestToSmallest(toList("2.7, 2.7, 2.7")), 0.0, 0.000001);
	check_within(__LINE__, distSecondSmallestToSmallest(toList("1.0, 2.0, 4.0")), 1.0, 0.000001);
	check_within(__LINE__, distSecondSmallestToSmallest(toList("4.0, 2.0, 1.0")), 1.0, 0.000001);
	check_within(__LINE__, distSecondSmallestToSmallest(toList("4.0, 2.0, -1.0")), 3.0, 0.000001);
	return 0;
}

int main(void) {
	tests();
	return EXIT_SUCCESS;
}
