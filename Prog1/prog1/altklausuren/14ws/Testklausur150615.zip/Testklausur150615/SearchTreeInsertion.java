/* Compile:
 * javac SearchTreeInsertion.java
 * 
 * Run:
 * java SearchTreeInsertion
 */

import java.util.Random;

class Node {
	public int value;
	public Node left, right;

	/** Constructor with child nodes. */
	public Node(Node left, int value, Node right) {
		this.left = left;
		this.value = value;
		this.right = right;
	}

	/** Constructor without child nodes. */
	public Node(int value) {
		this.value = value;
		left = null;
		right = null;
	}
	
	/** Insert a value into the search tree. */
	public void insert(int v) {
		// todo: implement
	}

	/** The depth of the tree. */
	public int depth() {
		if (left == null && right == null) {
			return 1;
		} 
		else if (left != null && right == null) {
			return 1 + left.depth();
		} 
		else if (left == null && right != null) {
			return 1 + right.depth();
		} 
		else {
			return 1 + Math.max(left.depth(), right.depth());
		} 
	}

	/** A String representation of this tree. */
	public String toString() {
		return "(" + (left == null ? "_" : left.toString()) 
				+ ", " + value + ", "
				+ (right == null ? "_" : right.toString()) + ")";
	}

}

class Tree {

	public Node root = null;
	
	public String toString() {
		if (root == null) return "_";
		else return root.toString();
	}

	public void insert(int... values) {
		if (values != null && values.length > 0) {
			int i = 0;
			if (root == null) {
				root = new Node(values[i++]);
			}
			for (; i < values.length; i++) {
				root.insert(values[i]);
			}
		}
	}
	
	public int depth() {
		if (root == null) return 0;
		return root.depth();
	}
	
}

public class SearchTreeInsertion {

	private final static Random rnd = new Random(System.currentTimeMillis());

	/** Randomly shuffle the array. */
	public static void shuffle(int[] a) {
		for (int i = a.length - 1; i > 0; i--) {
			int r = rnd.nextInt(i + 1);
			int h = a[r];
			a[r] = a[i];
			a[i] = h;
		}
	}

	public static void testInsert() {
		Tree t = new Tree();
		t.insert(1, 2, 3);
		boolean correct = t.root != null && t.root.value == 1 && 
			t.root.right != null && t.root.right.value == 2 && 
			t.root.right.right != null && t.root.right.right.value == 3;
		System.out.println(correct ? "test passed" : "test failed");

		t = new Tree();
		t.insert(3, 2, 1);
		correct = t.root != null && t.root.value == 3 && 
			t.root.left != null && t.root.left.value == 2 && 
			t.root.left.left != null && t.root.left.left.value == 1;
		System.out.println(correct ? "test passed" : "test failed");

		t = new Tree();
		t.insert(2, 1, 3);
		correct = t.root != null && t.root.value == 2 && 
			t.root.left != null && t.root.left.value == 1 && 
			t.root.right != null && t.root.right.value == 3;
		System.out.println(correct ? "test passed" : "test failed");

		t = new Tree();
		t.insert(2, 3, 1);
		correct = t.root != null && t.root.value == 2 && 
			t.root.left != null && t.root.left.value == 1 && 
			t.root.right != null && t.root.right.value == 3;
		System.out.println(correct ? "test passed" : "test failed");
	}
	
	public static void depthHistogram() {
		// create an array of size N with values 1, 2, ..., N
		int N = 10000;
		int[] a = new int[N];
		for (int i = 0; i < N; i++) {
			a[i] = i + 1;
		}

		// compute T search trees
		// each initialized with a random permutation of elements 1..N
		int T = 250;
		int[] depths = new int[T];
		int minDepth = N + 1;
		int maxDepth = 0;
		for (int i = 0; i < T; i++) {
			shuffle(a);
			Tree t = new Tree();
			t.insert(a);
			depths[i] = t.depth();
			maxDepth = Math.max(depths[i], maxDepth);
			minDepth = Math.min(depths[i], minDepth);
		}
		
		System.out.printf("min depth = %d, max depth = %d\n", minDepth, maxDepth);
		
		// generate a histogram of this kind:
		// 11: **** 4
		// 12: ** 2
		// 13: ******* 7
		// 14: ***** 5
		// 15: ** 2
		//
		// Generate a histogram that shows how often each tree depth occurred. In the
		// example above, depth 11 occurred 4 times. The minimum depth was 11 the 
		// maximum depth was 15.
		
		// todo: implement
	}

	public static void main(String[] args) {
		testInsert();
		// depthHistogram();
	}

}
