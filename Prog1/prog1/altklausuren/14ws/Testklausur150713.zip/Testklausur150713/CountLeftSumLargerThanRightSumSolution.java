/* Compile:
 * javac CountLeftSumLargerThanRightSum.java
 * 
 * Run:
 * java CountLeftSumLargerThanRightSum
 */

class Node {
	public int value;
	public Node left, right;

	public Node(Node left, int value, Node right) {
		this.left = left;
		this.value = value;
		this.right = right;
	}

	public int countLeftSumLargerThanRightSum() {
		if (left == null && right == null) {
			return 0;
		}
		if (left != null && right == null) {
			return left.countLeftSumLargerThanRightSum() + 
				(left.sum() > 0 ? 1 : 0);
		}
		if (left == null && right != null) {
			return right.countLeftSumLargerThanRightSum() + 
				(right.sum() < 0 ? 1 : 0);
		}
		return left.countLeftSumLargerThanRightSum() + 
			right.countLeftSumLargerThanRightSum() + 
				(left.sum() > right.sum() ? 1 : 0);
	}
	
	public int sum() {
		if (left == null && right == null) {
			return value;
		}
		if (left != null && right == null) {
			return left.sum() + value;
		}
		if (left == null && right != null) {
			return value + right.sum();
		}
		return left.sum() + value + right.sum();
	}
}

public class CountLeftSumLargerThanRightSum {

	public static Node n(int value) {
		return new Node(null, value, null);
	}
	
	public static Node n(Node left, int value, Node right) {
		return new Node(left, value, right);
	}

	public static boolean tests() {
		Node node = n(4);
		if (0 != node.countLeftSumLargerThanRightSum()) return false;
		
		node = n(n(n(3), 1, n(2)), 3, n(9));
		if (1 != node.countLeftSumLargerThanRightSum()) return false;
		
		node = n(n(9), 3, n(n(3), 1, n(2)));
		if (2 != node.countLeftSumLargerThanRightSum()) return false;
		
		node = n(n(3), 3, null);
		if (1 != node.countLeftSumLargerThanRightSum()) return false;
		
		node = n(n(0), 3, null);
		if (0 != node.countLeftSumLargerThanRightSum()) return false;
		
		node = n(null, 3, n(0));
		if (0 != node.countLeftSumLargerThanRightSum()) return false;
		
		node = n(null, 3, n(-1));
		if (1 != node.countLeftSumLargerThanRightSum()) return false;
		
		return true;
	}

	public static void main(String[] args) {
		if (tests()) System.out.println("tests passed"); 
		else System.out.println("tests failed");
	}

}
